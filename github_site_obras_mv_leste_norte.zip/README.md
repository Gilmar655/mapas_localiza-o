# Site de Obras MV Leste / Norte

Site de acompanhamento de obras da região MV Leste / Norte.

## Conteúdo

- `index.html`: arquivo principal do site, pronto para publicação no GitHub Pages.
- Base atualizada com a programação de obras de 18/05/2026 a 25/05/2026.
- Mapa interativo com Leaflet/OpenStreetMap.
- Incorporação do Google My Maps.
- Filtros por contratada, data, status, tipo de intervenção e família.
- Tabela completa e exportação CSV.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Acesse **Settings > Pages**.
4. Em **Build and deployment**, selecione:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
5. Salve e aguarde a geração do link do GitHub Pages.
